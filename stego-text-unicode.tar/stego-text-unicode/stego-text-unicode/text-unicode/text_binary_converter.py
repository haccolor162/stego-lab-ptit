import sys
import os

def text_to_binary(text):
    """Chuyển chuỗi ký tự thành chuỗi bit nhị phân (mỗi ký tự thành 8 bit ASCII)."""
    try:
        return ''.join(format(ord(c), '08b') for c in text)
    except ValueError as e:
        raise ValueError("Không thể chuyển đổi ký tự thành nhị phân: " + str(e))

def binary_to_text(binary):
    """Chuyển chuỗi bit nhị phân thành chuỗi ký tự (giải mã 8 bit thành ASCII)."""
    if len(binary) % 8 != 0:
        raise ValueError("Chuỗi nhị phân không hợp lệ: độ dài không chia hết cho 8")
    chars = []
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        try:
            chars.append(chr(int(byte, 2)))
        except ValueError:
            raise ValueError(f"Không thể giải mã byte nhị phân: {byte}")
    return ''.join(chars)

def main():
    if len(sys.argv) < 4:
        print("Cách dùng:")
        print("Chuyển văn bản thành nhị phân: python converter.py to_binary <input_file> <output_file>")
        print("Chuyển nhị phân thành văn bản: python converter.py to_text <input_file> <output_file>")
        sys.exit(1)

    mode = sys.argv[1].lower()
    input_file = sys.argv[2]
    output_file = sys.argv[3]

    # Kiểm tra tệp đầu vào tồn tại
    if not os.path.exists(input_file):
        print(f"Tệp đầu vào {input_file} không tồn tại")
        sys.exit(1)

    # Chế độ chuyển văn bản thành nhị phân
    if mode == "to_binary":
        try:
            # Đọc văn bản từ tệp
            with open(input_file, 'r', encoding='utf-8') as f:
                text = f.read().strip()
            if not text:
                print("Tệp đầu vào trống")
                sys.exit(1)
            
            # Chuyển thành nhị phân
            binary = text_to_binary(text)
            
            # Ghi chuỗi nhị phân vào tệp
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(binary)
            
            print(f"Đã chuyển văn bản thành nhị phân. Kết quả lưu vào {output_file}")
            print(f"Văn bản gốc: {text}")
            print(f"Chuỗi nhị phân: {binary}")
        
        except ValueError as e:
            print("Lỗi khi chuyển đổi:", e)
            sys.exit(1)

    # Chế độ chuyển nhị phân thành văn bản
    elif mode == "to_text":
        try:
            # Đọc chuỗi nhị phân từ tệp
            with open(input_file, 'r', encoding='utf-8') as f:
                binary = f.read().strip()
            if not binary:
                print("Tệp đầu vào trống")
                sys.exit(1)
            
            # Kiểm tra chuỗi nhị phân chỉ chứa 0 và 1
            if not all(c in '01' for c in binary):
                print("Chuỗi nhị phân không hợp lệ: chỉ được chứa 0 và 1")
                sys.exit(1)
            
            # Chuyển thành văn bản
            text = binary_to_text(binary)
            
            # Ghi văn bản vào tệp
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(text)
            
            print(f"Đã chuyển nhị phân thành văn bản. Kết quả lưu vào {output_file}")
            print(f"Chuỗi nhị phân: {binary}")
            print(f"Văn bản: {text}")
        
        except ValueError as e:
            print("Lỗi khi chuyển đổi:", e)
            sys.exit(1)

    else:
        print("Chế độ không hợp lệ. Sử dụng 'to_binary' hoặc 'to_text'")
        sys.exit(1)

if __name__ == "__main__":
    main()
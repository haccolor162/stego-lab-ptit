import random
import sys
import os

latin_o = 'o'
cyrillic_o = 'о'
latin_O = 'O'
cyrillic_O = 'О'

def text_to_binary(text):

    return ''.join(format(ord(c), '08b') for c in text)

def binary_to_text(binary):

    if len(binary) % 8 != 0:
        raise ValueError("Chuỗi nhị phân không hợp lệ: độ dài không chia hết cho 8")
    chars = []
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        try:
            chars.append(chr(int(byte, 2)))
        except ValueError:
            raise ValueError("Không thể giải mã byte nhị phân")
    return ''.join(chars)

def embed_watermark(text, watermark, key):
   
    text_list = list(text)
    potential_positions = [i for i, char in enumerate(text_list) if char in [latin_o, latin_O]]
    N = len(watermark)
    if len(potential_positions) < N:
        raise ValueError(f"Không đủ vị trí để nhúng watermark ({N} bit, chỉ có {len(potential_positions)} vị trí). Cần thêm ký tự 'o' hoặc 'O'.")
    random.seed(key)
    selected_positions = random.sample(potential_positions, N)
    for j, pos in enumerate(selected_positions):
        if watermark[j] == '1':
            if text_list[pos] == latin_o:
                text_list[pos] = cyrillic_o
            elif text_list[pos] == latin_O:
                text_list[pos] = cyrillic_O
    return ''.join(text_list)

def extract_watermark(watermarked_text, N, key):
   
    text_list = list(watermarked_text)
    potential_positions = [i for i, char in enumerate(text_list) if char in [latin_o, cyrillic_o, latin_O, cyrillic_O]]
    if len(potential_positions) < N:
        raise ValueError(f"Không đủ vị trí để trích xuất watermark ({N} bit, chỉ có {len(potential_positions)} vị trí)")
    random.seed(key)
    selected_positions = random.sample(potential_positions, N)
    watermark_bits = []
    for pos in selected_positions:
        char = text_list[pos]
        if char == cyrillic_o or char == cyrillic_O:
            watermark_bits.append('1')
        elif char == latin_o or char == latin_O:
            watermark_bits.append('0')
        else:
            raise ValueError("Ký tự không mong muốn tại vị trí watermark")
    return ''.join(watermark_bits)

def main():
    if len(sys.argv) < 2:
        print("Cách dùng:")
        print("Nhúng: python watermark.py embed <input_text_file> <message_file> <output_file> <key>")
        print("Trích xuất: python watermark.py extract <input_text_file> <output_file> <watermark_length> <key>")
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "embed":
        if len(sys.argv) != 6:
            print("Nhúng cần: <input_text_file> <message_file> <output_file> <key>")
            sys.exit(1)
        input_text_file = sys.argv[2]
        message_file = sys.argv[3]
        output_file = sys.argv[4]
        try:
            key = int(sys.argv[5])
        except ValueError:
            print("Khóa phải là số nguyên")
            sys.exit(1)

        # Đọc văn bản gốc
        if not os.path.exists(input_text_file):
            print(f"Tệp văn bản {input_text_file} không tồn tại")
            sys.exit(1)
        with open(input_text_file, 'r', encoding='utf-8') as f:
            original_text = f.read()

        # Đọc thông điệp và chuyển thành nhị phân
        if not os.path.exists(message_file):
            print(f"Tệp thông điệp {message_file} không tồn tại")
            sys.exit(1)
        with open(message_file, 'r', encoding='utf-8') as f:
            message = f.read().strip()
        if not message:
            print("Tệp thông điệp trống")
            sys.exit(1)
        watermark = text_to_binary(message)
        print(f"Thông điệp: {message}")
        print(f"Watermark nhị phân: {watermark} (độ dài: {len(watermark)} bit)")

        # Nhúng watermark
        try:
            watermarked_text = embed_watermark(original_text, watermark, key)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(watermarked_text)
            print(f"Đã nhúng watermark. Văn bản được lưu vào {output_file}")
            print("Mã Unicode của các ký tự o/O:", [ord(c) for c in watermarked_text if c in [latin_o, cyrillic_o, latin_O, cyrillic_O]])
        except ValueError as e:
            print("Lỗi khi nhúng:", e)
            sys.exit(1)

    elif mode == "extract":
        if len(sys.argv) != 6:
            print("Trích xuất cần: <input_text_file> <output_file> <watermark_length> <key>")
            sys.exit(1)
        input_text_file = sys.argv[2]
        output_file = sys.argv[3]
        try:
            watermark_length = int(sys.argv[4])
        except ValueError:
            print("Độ dài watermark (số bit) phải là số nguyên")
            sys.exit(1)
        try:
            key = int(sys.argv[5])
        except ValueError:
            print("Khóa phải là số nguyên")
            sys.exit(1)

        # Đọc văn bản đã nhúng
        if not os.path.exists(input_text_file):
            print(f"Tệp văn bản {input_text_file} không tồn tại")
            sys.exit(1)
        with open(input_text_file, 'r', encoding='utf-8') as f:
            watermarked_text = f.read()

        # Trích xuất watermark
        try:
            extracted_watermark = extract_watermark(watermarked_text, watermark_length, key)
            # Lưu chuỗi nhị phân vào tệp
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(extracted_watermark)
            # Hiển thị thông điệp dạng ký tự để kiểm tra
            try:
                extracted_message = binary_to_text(extracted_watermark)
                print(f"Đã trích xuất watermark. Chuỗi nhị phân được lưu vào {output_file}")
                print(f"Watermark nhị phân: {extracted_watermark}")
              
            except ValueError as e:
                print(f"Đã trích xuất watermark. Chuỗi nhị phân được lưu vào {output_file}")
                print(f"Watermark nhị phân: {extracted_watermark}")
                print(f"Không thể giải mã thành ký tự: {e}")
        except ValueError as e:
            print("Lỗi khi trích xuất:", e)
            sys.exit(1)

    else:
        print("Chế độ không hợp lệ. Sử dụng 'embed' hoặc 'extract'")
        sys.exit(1)

if __name__ == "__main__":
    main()

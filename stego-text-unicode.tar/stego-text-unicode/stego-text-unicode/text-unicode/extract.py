import random

latin_o = 'o'
cyrillic_o = 'о'
latin_O = 'O'
cyrillic_O = 'О'

def extract_watermark(watermarked_text, N, key):
    text_list = list(watermarked_text)
    potential_positions = [i for i, char in enumerate(text_list) if char in [latin_o, cyrillic_o, latin_O, cyrillic_O]]
    if len(potential_positions) < N:
        raise ValueError("Không đủ vị trí để trích xuất watermark")
    random.seed(key)
    selected_positions = random.sample(potential_positions, N)
    watermark_bits = []
    for pos in selected_positions:
        char = text_list[pos]
        if char == cyrillic_o or char == cyrillic_O:
            watermark_bits.append('1')
        elif char == latin_o or char == latin_O:
            watermark_bits.append('0')
        else:
            raise ValueError("Ký tự không mong muốn tại vị trí watermark")
    return ''.join(watermark_bits)

if __name__ == "__main__":
    watermarked_text = "The quick brown fox jumps over the lazy dog. Open the dооr."  
    N = 3  
    key = 42
    try:
        extracted_watermark = extract_watermark(watermarked_text, N, key)
        print("Văn bản đã nhúng:", watermarked_text)
        print("Watermark được trích xuất:", extracted_watermark)
    except ValueError as e:
        print("Lỗi khi trích xuất:", e)
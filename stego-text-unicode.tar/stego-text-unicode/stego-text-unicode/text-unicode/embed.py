import random

latin_o = 'o'
cyrillic_o = 'о'
latin_O = 'O'
cyrillic_O = 'О'

def embed_watermark(text, watermark, key):
    text_list = list(text)
    potential_positions = [i for i, char in enumerate(text_list) if char in [latin_o, latin_O]]
    N = len(watermark)
    if len(potential_positions) < N:
        raise ValueError("Không đủ vị trí để nhúng watermark")
    random.seed(key)
    selected_positions = random.sample(potential_positions, N)
    for j, pos in enumerate(selected_positions):
        if watermark[j] == '1':
            if text_list[pos] == latin_o:
                text_list[pos] = cyrillic_o
            elif text_list[pos] == latin_O:
                text_list[pos] = cyrillic_O
    return ''.join(text_list)

if __name__ == "__main__":
    original_text = "The quick brown fox jumps over the lazy dog. Open the door."
    watermark = "101"
    key = 42
    try:
        watermarked_text = embed_watermark(original_text, watermark, key)
        print("Văn bản gốc:", original_text)
        print("Văn bản sau khi nhúng:", watermarked_text)
        print("Mã Unicode của văn bản nhúng:", [ord(c) for c in watermarked_text if c in [latin_o, cyrillic_o, latin_O, cyrillic_O]])
    except ValueError as e:
        print("Lỗi khi nhúng:", e)
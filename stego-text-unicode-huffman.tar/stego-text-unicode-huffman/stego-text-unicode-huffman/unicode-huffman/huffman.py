import sys
import os
import heapq
from collections import defaultdict
import json

def build_huffman_tree(text):
    """Xây dựng cây Huffman và trả về bảng mã."""
    if not text:
        raise ValueError("Văn bản đầu vào trống, không thể xây dựng cây Huffman")
    # Tính tần suất ký tự
    freq = defaultdict(int)
    for char in text:
        freq[char] += 1
    
    # Xây dựng hàng đợi ưu tiên
    heap = [[weight, [char, ""]] for char, weight in freq.items()]
    heapq.heapify(heap)
    
    # Kết hợp các nút
    while len(heap) > 1:
        lo = heapq.heappop(heap)
        hi = heapq.heappop(heap)
        for pair in lo[1:]:
            pair[1] = '0' + pair[1]
        for pair in hi[1:]:
            pair[1] = '1' + pair[1]
        heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
    
    # Tạo bảng mã
    huffman_table = dict(sorted(heap[0][1:], key=lambda p: (len(p[-1]), p)))
    return huffman_table

def huffman_encode(text, huffman_table):
    """Mã hóa văn bản bằng bảng mã Huffman."""
    return ''.join(huffman_table[char] for char in text)

def huffman_decode(binary, huffman_table):
    """Giải mã chuỗi nhị phân bằng bảng mã Huffman."""
    reverse_table = {code: char for char, code in huffman_table.items()}
    decoded = ""
    current_code = ""
    for bit in binary:
        current_code += bit
        if current_code in reverse_table:
            decoded += reverse_table[current_code]
            current_code = ""
    if current_code:
        raise ValueError(f"Chuỗi nhị phân không hợp lệ cho bảng mã Huffman: {binary}")
    return decoded

def main():
    if len(sys.argv) < 2:
        print("Cách dùng:")
        print("Mã hóa: python huffman.py encode <input_file> <output_file> <huffman_table_file>")
        print("Giải mã: python huffman.py decode <input_file> <huffman_table_file> <output_file>")
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "encode":
        if len(sys.argv) != 5:
            print("Mã hóa cần: <input_file> <output_file> <huffman_table_file>")
            sys.exit(1)
        input_file = sys.argv[2]
        output_file = sys.argv[3]
        huffman_table_file = sys.argv[4]

        # Đọc văn bản đầu vào
        if not os.path.exists(input_file):
            print(f"Tệp đầu vào {input_file} không tồn tại")
            sys.exit(1)
        with open(input_file, 'r', encoding='utf-8') as f:
            text = f.read().strip()
        if not text:
            print("Tệp đầu vào trống")
            sys.exit(1)

        # Mã hóa Huffman
        try:
            huffman_table = build_huffman_tree(text)
            binary = huffman_encode(text, huffman_table)
            
            # Lưu chuỗi nhị phân
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(binary)
            
            # Lưu bảng mã Huffman
            with open(huffman_table_file, 'w', encoding='utf-8') as f:
                json.dump(huffman_table, f)
            
            print(f"Đã mã hóa Huffman. Chuỗi nhị phân lưu vào {output_file}")
            print(f"Bảng mã Huffman lưu vào {huffman_table_file}")
            print(f"Văn bản gốc: {text}")
            print(f"Chuỗi nhị phân: {binary} (độ dài: {len(binary)} bit)")
        
        except ValueError as e:
            print("Lỗi khi mã hóa:", e)
            sys.exit(1)

    elif mode == "decode":
        if len(sys.argv) != 5:
            print("Giải mã cần: <input_file> <huffman_table_file> <output_file>")
            sys.exit(1)
        input_file = sys.argv[2]
        huffman_table_file = sys.argv[3]
        output_file = sys.argv[4]

        # Đọc chuỗi nhị phân
        if not os.path.exists(input_file):
            print(f"Tệp đầu vào {input_file} không tồn tại")
            sys.exit(1)
        with open(input_file, 'r', encoding='utf-8') as f:
            binary = f.read().strip()
        if not binary:
            print("Tệp đầu vào trống")
            sys.exit(1)
        
        # Kiểm tra chuỗi nhị phân
        if not all(c in '01' for c in binary):
            print("Chuỗi nhị phân không hợp lệ: chỉ được chứa 0 và 1")
            sys.exit(1)

        # Đọc bảng mã Huffman
        if not os.path.exists(huffman_table_file):
            print(f"Tệp bảng mã Huffman {huffman_table_file} không tồn tại")
            sys.exit(1)
        with open(huffman_table_file, 'r', encoding='utf-8') as f:
            huffman_table = json.load(f)

        # Giải mã
        try:
            text = huffman_decode(binary, huffman_table)
            
            # Lưu văn bản giải mã
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(text)
            
            print(f"Đã giải mã Huffman. Văn bản lưu vào {output_file}")
            print(f"Chuỗi nhị phân: {binary}")
            print(f"Văn bản giải mã: {text}")
        
        except ValueError as e:
            print("Lỗi khi giải mã:", e)
            sys.exit(1)

    else:
        print("Chế độ không hợp lệ. Sử dụng 'encode' hoặc 'decode'")
        sys.exit(1)

if __name__ == "__main__":
    main()
huffman encode :
python huffman.py encode message.txt binary.txt huffman_table.txt

embed :
python watermark.py embed input.txt message.txt output_embedded.txt 42

extract :
python watermark.py extract output_embedded.txt output_extracted.txt 10 huffman_table.txt 42

b2t :
python text_binary_converter.py to_text binary.txt extracted_message.txt
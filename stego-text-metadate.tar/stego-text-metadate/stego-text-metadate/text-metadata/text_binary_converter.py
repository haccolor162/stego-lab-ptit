import argparse

def text_to_binary(text):
    """Chuyển đổi văn bản thành chuỗi nhị phân."""
    binary = [format(ord(char), '08b') for char in text]
    return ' '.join(binary)

def binary_to_text(binary):
    """Chuyển đổi chuỗi nhị phân thành văn bản."""
    # Loại bỏ khoảng trắng thừa và chia thành các khối 8 bit
    binary_chunks = binary.strip().split()
    text = ''
    for chunk in binary_chunks:
        if len(chunk) == 8 and chunk.isdigit():  # Đảm bảo khối hợp lệ
            try:
                char_code = int(chunk, 2)
                text += chr(char_code)
            except ValueError:
                continue
    return text

def main():
    # Thiết lập trình phân tích tham số dòng lệnh
    parser = argparse.ArgumentParser(description="Chuyển đổi văn bản thành nhị phân và ngược lại")
    parser.add_argument('mode', choices=['text2bin', 'bin2text'], help="Chế độ: text2bin hoặc bin2text")
    parser.add_argument('--input_file', required=True, help="File chứa văn bản hoặc chuỗi nhị phân đầu vào")
    parser.add_argument('--output_file', required=True, help="File để lưu kết quả")

    args = parser.parse_args()

    # Đọc dữ liệu từ file đầu vào
    try:
        with open(args.input_file, 'r', encoding='utf-8') as f:
            input_data = f.read()
    except Exception as e:
        print(f"Lỗi khi đọc file đầu vào: {e}")
        return

    # Xử lý theo chế độ
    if args.mode == 'text2bin':
        # Chuyển đổi văn bản thành chuỗi nhị phân
        result = text_to_binary(input_data)
        success_message = "Chuỗi nhị phân đã được lưu vào:"

    elif args.mode == 'bin2text':
        # Chuyển đổi chuỗi nhị phân thành văn bản
        result = binary_to_text(input_data)
        success_message = "Văn bản đã được lưu vào:"

    # Ghi kết quả ra file
    try:
        with open(args.output_file, 'w', encoding='utf-8') as f:
            f.write(result)
        print(f"{success_message} {args.output_file}")
    except Exception as e:
        print(f"Lỗi khi ghi file đầu ra: {e}")

if __name__ == "__main__":
    main()
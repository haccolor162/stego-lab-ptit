import argparse

# Định nghĩa các ký tự zero-width
zero_width_chars = {
    '0': '\u200B',  # ZERO WIDTH SPACE
    '1': '\u200C'   # ZERO WIDTH NON-JOINER
}

def encode_message(cover_text, secret_message):
    """Mã hóa thông điệp bí mật vào văn bản bìa."""
    # Chuyển đổi thông điệp bí mật thành chuỗi nhị phân
    binary_message = ''.join(format(ord(char), '08b') for char in secret_message)
    
    # Kiểm tra độ dài văn bản bìa
    required_length = len(binary_message)
    if len(cover_text) < required_length:
        raise ValueError(f"Văn bản bìa cần ít nhất {required_length} ký tự để chứa thông điệp, nhưng chỉ có {len(cover_text)} ký tự.")
    
    # Nhúng thông điệp nhị phân vào văn bản bìa bằng cách chèn ký tự zero-width
    stego_text = list(cover_text)
    bit_index = 0
    for i in range(len(stego_text)):
        if bit_index < len(binary_message):
            # Chèn ký tự zero-width sau mỗi ký tự trong văn bản bìa
            stego_text.insert(2*i + 1, zero_width_chars[binary_message[bit_index]])
            bit_index += 1
        if bit_index >= len(binary_message):
            break
    
    return ''.join(stego_text)

def decode_message(stego_text):
    """Giải mã thông điệp từ văn bản đã nhúng và trả về chuỗi nhị phân."""
    # Trích xuất các ký tự zero-width
    extracted_bits = ''
    for char in stego_text:
        if char in zero_width_chars.values():
            for key, value in zero_width_chars.items():
                if char == value:
                    extracted_bits += key
                    break
    
    # Định dạng chuỗi nhị phân thành các khối 8 bit, phân tách bằng dấu cách
    binary_chunks = [extracted_bits[i:i+8] for i in range(0, len(extracted_bits), 8)]
    formatted_binary = ' '.join(chunk for chunk in binary_chunks if len(chunk) == 8)
    
    return formatted_binary

def main():
    # Thiết lập trình phân tích tham số dòng lệnh
    parser = argparse.ArgumentParser(description="Giấu tin trong văn bản sử dụng ký tự zero-width, giải mã trả về chuỗi nhị phân")
    parser.add_argument('mode', choices=['encode', 'decode'], help="Chế độ: encode hoặc decode")
    parser.add_argument('--cover_file', help="File chứa văn bản bìa (cho encode)")
    parser.add_argument('--secret_message', help="Thông điệp bí mật cần ẩn (cho encode)")
    parser.add_argument('--input_file', help="File chứa văn bản đã nhúng (cho decode)")
    parser.add_argument('--output_file', required=True, help="File để lưu kết quả")

    args = parser.parse_args()

    if args.mode == 'encode':
        if not args.cover_file or not args.secret_message:
            parser.error("encode yêu cầu --cover_file và --secret_message")
        
        # Đọc văn bản bìa từ file
        try:
            with open(args.cover_file, 'r', encoding='utf-8') as f:
                cover_text = f.read()
        except Exception as e:
            print(f"Lỗi khi đọc file văn bản bìa: {e}")
            return

        # Mã hóa thông điệp
        try:
            stego_text = encode_message(cover_text, args.secret_message)
        except ValueError as e:
            print(f"Lỗi khi mã hóa: {e}")
            return

        # Ghi kết quả ra file
        try:
            with open(args.output_file, 'w', encoding='utf-8') as f:
                f.write(stego_text)
            print(f"Văn bản đã nhúng được lưu vào: {args.output_file}")
        except Exception as e:
            print(f"Lỗi khi ghi file đầu ra: {e}")

    elif args.mode == 'decode':
        if not args.input_file:
            parser.error("decode yêu cầu --input_file")
        
        # Đọc văn bản đã nhúng từ file
        try:
            with open(args.input_file, 'r', encoding='utf-8') as f:
                stego_text = f.read()
        except Exception as e:
            print(f"Lỗi khi đọc file đầu vào: {e}")
            return

        # Giải mã thông điệp dưới dạng chuỗi nhị phân
        binary_message = decode_message(stego_text)

        # Ghi kết quả ra file
        try:
            with open(args.output_file, 'w', encoding='utf-8') as f:
                f.write(binary_message)
            print(f"Chuỗi nhị phân giải mã được lưu vào: {args.output_file}")
        except Exception as e:
            print(f"Lỗi khi ghi file đầu ra: {e}")

if __name__ == "__main__":
    main()
tẽt to bit : 
python text_binary_converter.py text2bin --input_file stego.txt --output_file output_binary.txt

bit to text :
python text_binary_converter.py bin2text --input_file secret.txt --output_file output_text.txt 

nhung :
python steganography.py encode --cover_file cover.txt --secret_message "b21dcat054" --output_file stego.txt

tach :
python steganography.py decode --input_file stego.txt --output_file secret.txt
